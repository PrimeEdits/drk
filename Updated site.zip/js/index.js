var isFormActive = false;
var isNotificationsActive = false;
var duration = .2;
var transitionY = 10;
var easing = Sine.easeOut;

var notifyButton = document.getElementsByClassName('notify')[0];
var newsletterButton = document.getElementsByClassName('newsletter')[0];

var emailInput = document.getElementsByClassName('email-input')[0];
var nameInput = document.getElementsByClassName('name-input')[0];

var form = document.getElementsByClassName('form')[0];

//TweenLite.set(form, {opacity: 0, y: transitionY})
TweenLite.set(notifyButton, { opacity: 1, y: 0 });
TweenLite.set(emailInput, { opacity: 0, y: transitionY });
TweenLite.set(nameInput, { opacity: 0, y: transitionY });

newsletterButton.addEventListener("click", function () {
  if (isFormActive) {
    var tl = new TimelineLite();
    tl.call(function () {
      document.body.classList.remove('is-form');
    });
    tl.to(emailInput, duration, { opacity: 0, y: transitionY, ease: easing });
    tl.to(nameInput, duration, { opacity: 0, y: transitionY, ease: easing }, '-0.1');
    tl.to(notifyButton, duration, { opacity: 1, y: 0, ease: easing });
    tl.play();
  } else {
    var tl = new TimelineLite();
    tl.call(function () {
      document.body.classList.add('is-form');
    });
    tl.to(notifyButton, 0.15, { opacity: 0, y: -transitionY, ease: easing });
    tl.to(emailInput, 0.15, { opacity: 1, y: 0, ease: easing }, '+0.1');
    tl.call(function () {
      emailInput.focus();
    });
    tl.to(nameInput, duration, { opacity: 1, y: 0, ease: easing });
    tl.play();
  }
  isFormActive = !isFormActive;
});

notifyButton.addEventListener("click", function () {
  if (isNotificationsActive) {
    document.body.classList.remove('is-notify');
  } else {
    document.body.classList.add('is-notify');
  }
  isNotificationsActive = !isNotificationsActive;
});